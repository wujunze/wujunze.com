# Yilia Theme Port To Typecho

####主题说明

Yilia原来是一个Hexo的主题，作者为[Litten](http://litten.github.io/)

这里是Yilia的Typecho移植+个人修改版

如有与原主题不同之处纯属正常。

侧栏的社交链接请手动修改(我不用微博)

注意修改头像图片呀。。

####主题演示

![Screenshot](https://github.com/lingmm/yilia-theme-port-to-typecho/raw/master/screenshot.png)

DEMO ON <https://shyling.com>